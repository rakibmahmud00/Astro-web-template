$(document).ready(function () {

    function googleTranslateElementInit() {
        new google.translate.TranslateElement({ pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE, autoDisplay: false }, 'google_translate_element');
    }

    function translateLanguage(lang) {
        googleTranslateElementInit();
        var $frame = $('.goog-te-menu-frame:first');
        if (!$frame.size()) {
            alert("Error: Could not find Google translate frame.");
            return false;
        }
        $frame.contents().find('.goog-te-menu2-item span.text:contains(' + lang + ')').get(0).click();
        return false;
    }

    $(function () {
        $('.selectpicker').selectpicker();
    });

    //TopSearchBarFunction
    var availTags = [
        "Home",
        "About",
        "Pricing",
        "Blog",
        "Services",
        "Contact",
        "Domains",
        "Single-Blog",
        "How to create domains ?",
        "Transfer domain ?"
    ]

    $('#searchbarTop').autocomplete({
        source: availTags
    })

    //BlogSearchFunction
    var availTags = [
        "Graphic Design",
        "Video",
        "Audio",
        "Business",
        "Photography",
        "Web Design",
        "Media",
    ]

    $('#searchbarBlogs').autocomplete({
        source: availTags
    })

    $('.burger').click(function () {

        $('.right-part').toggleClass("v-class")
        $('.menu-itms').toggleClass("h-class")
    })

    $('.blogSearch').search();


});



